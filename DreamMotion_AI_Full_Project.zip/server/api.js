import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json({limit:'2mb'}));

app.get('/api/health', (_req,res)=>res.json({ok:true,app:'DreamMotion AI',status:'starter'}));

app.post('/api/generate', async (req,res)=>{
  const {mode,prompt,style,duration,ratio} = req.body || {};
  if (!prompt || typeof prompt !== 'string') return res.status(400).json({error:'A prompt is required.'});
  if (!['image','text'].includes(mode)) return res.status(400).json({error:'mode must be image or text.'});

  // TODO: Integrate a real video-generation provider here.
  // Keep provider API keys in server environment variables, never in public/index.html.
  // For image-to-video, accept an uploaded image via a secure upload endpoint or signed object-storage URL.
  // Implement provider job polling, error handling, safety checks, rate limits, and result storage.
  return res.status(501).json({
    error:'Video provider is not connected yet.',
    nextStep:'Configure a supported video-generation API in this server before generating real videos.',
    request:{mode,style,duration,ratio}
  });
});

const port = process.env.PORT || 3000;
app.listen(port, ()=>console.log(`DreamMotion API listening on port ${port}`));
